const {Router} = require('express');

const router = Router();

const {storeClientes, mostrarClientes} = require('../controller/clientesController');

router.post('/store/clientes', storeClientes);
router.post('/store/mostrarClientes', mostrarClientes);

module.exports = router;